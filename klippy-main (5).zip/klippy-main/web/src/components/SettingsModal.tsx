import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { PeoplePanel } from './PeoplePanel';
import { LabelsPanel } from './LabelsPanel';
import { ProfilePanel } from './ProfilePanel';
import { TeamsPanel } from './TeamsPanel';
import { TokensPanel } from './TokensPanel';
import { AppearancePanel } from './AppearancePanel';
import { BrandingPanel } from './BrandingPanel';
import { NotesPanel } from './NotesPanel';

type Tab = 'profile' | 'appearance' | 'workspace' | 'branding' | 'people' | 'teams' | 'labels' | 'tokens' | 'notes';

export function SettingsModal({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('profile');

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-slate-700 bg-slate-950" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3">
          <h2 className="text-lg font-semibold text-slate-100">Settings</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-800"><X size={16} /></button>
        </div>

        <div className="flex gap-1 overflow-x-auto border-b border-slate-800 px-4 pt-2">
          {(['profile', 'appearance', 'workspace', 'branding', 'people', 'teams', 'labels', 'tokens', 'notes'] as Tab[]).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`shrink-0 rounded-t-lg px-3 py-2 text-sm font-medium capitalize ${tab === t ? 'bg-slate-900 text-slate-100' : 'text-slate-400 hover:text-slate-200'}`}>
              {t}
            </button>
          ))}
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto p-5">
          {tab === 'profile' && <ProfilePanel />}
          {tab === 'appearance' && <AppearancePanel />}
          {tab === 'workspace' && <WorkspaceTab />}
          {tab === 'branding' && <BrandingPanel />}
          {tab === 'people' && <PeoplePanel />}
          {tab === 'teams' && <TeamsPanel />}
          {tab === 'labels' && <LabelsPanel />}
          {tab === 'tokens' && <TokensPanel />}
          {tab === 'notes' && <NotesPanel />}
        </div>
      </div>
    </div>
  );
}

function WorkspaceTab() {
  const { account, user, updateAccount } = useAuth();
  const [name, setName] = useState(account?.name ?? '');
  const [singular, setSingular] = useState(account?.folderLabelSingular ?? 'Client');
  const [plural, setPlural] = useState(account?.folderLabelPlural ?? 'Clients');
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  
  const isAdmin = user?.role === 'owner' || user?.role === 'admin';
  const isOwner = user?.role === 'owner'; // Only owners can delete the workspace

  async function save(e: FormEvent) {
    e.preventDefault();
    setError(null); setSaved(false); setBusy(true);
    try {
      await updateAccount({ name: name.trim(), folderLabelSingular: singular.trim(), folderLabelPlural: plural.trim() });
      setSaved(true); setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save.');
    } finally { setBusy(false); }
  }

  const field = 'w-full rounded-lg bg-slate-900/70 border border-slate-700 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-violet-500 disabled:opacity-50';

  return (
    <div className="space-y-8">
      <form onSubmit={save} className="space-y-4">
        {!isAdmin && <p className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-400">Only workspace admins can change these settings.</p>}
        <div>
          <label className="mb-1 block text-xs font-medium text-slate-400">Workspace name</label>
          <input className={field} value={name} disabled={!isAdmin} onChange={(e) => setName(e.target.value)} placeholder="Mondobase" />
        </div>
        <div>
          <div className="mb-1 text-xs font-medium text-slate-400">What do you call your top-level folders?</div>
          <p className="mb-2 text-[11px] text-slate-500">Rename "Clients" to whatever fits: Businesses, Customers, Projects. Shown in the sidebar.</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-[11px] text-slate-500">Singular</label>
              <input className={field} value={singular} disabled={!isAdmin} onChange={(e) => setSingular(e.target.value)} placeholder="Client" />
            </div>
            <div>
              <label className="mb-1 block text-[11px] text-slate-500">Plural</label>
              <input className={field} value={plural} disabled={!isAdmin} onChange={(e) => setPlural(e.target.value)} placeholder="Clients" />
            </div>
          </div>
        </div>
        {error && <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</div>}
        {isAdmin && (
          <div className="flex items-center gap-3">
            <button type="submit" disabled={busy} className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-[var(--accent-ink)] hover:bg-violet-500 disabled:opacity-60">
              {busy ? 'Saving...' : 'Save changes'}
            </button>
            {saved && <span className="text-sm text-green-400">Saved</span>}
          </div>
        )}
      </form>

      {/* Render the delete button for owners only */}
      {isOwner && account?.id && (
        <div className="pt-4 border-t border-slate-800">
          <DeleteWorkspaceButton workspaceId={account.id} />
        </div>
      )}
    </div>
  );
}

export function DeleteWorkspaceButton({ workspaceId }: { workspaceId: number }) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    const confirmed = window.confirm(
      "Are you absolutely sure? This will permanently delete this workspace, including all businesses, boards, tasks, and files. This action CANNOT be undone."
    );

    if (!confirmed) return;

    setIsDeleting(true);

    try {
      const response = await fetch(`/api/v1/workspaces/${workspaceId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        window.location.href = '/'; 
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to delete workspace.');
        setIsDeleting(false);
      }
    } catch (error) {
      console.error("Error deleting workspace:", error);
      alert('An unexpected error occurred.');
      setIsDeleting(false);
    }
  };

  return (
    <div className="rounded-lg border border-red-900/50 bg-red-950/20 p-4">
      <h3 className="mb-1 text-sm font-semibold text-red-400">Danger Zone</h3>
      <p className="mb-4 text-xs text-red-300/70">
        Permanently delete this workspace and all of its data. This cannot be undone.
      </p>
      <button 
        onClick={handleDelete} 
        disabled={isDeleting}
        className="rounded-lg bg-red-500/10 px-4 py-2 text-sm font-medium text-red-400 border border-red-500/20 hover:bg-red-500/20 disabled:opacity-50 transition-colors"
      >
        {isDeleting ? 'Deleting...' : 'Delete Workspace'}
      </button>
    </div>
  );
}